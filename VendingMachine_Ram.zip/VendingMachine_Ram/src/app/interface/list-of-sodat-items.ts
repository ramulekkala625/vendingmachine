export interface ListOfSoda {
   id: string;
   name: string;
   price: number;
   quantitiy_available: number;
 }
