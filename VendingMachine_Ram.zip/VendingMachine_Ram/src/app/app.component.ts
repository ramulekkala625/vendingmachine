import { Component, OnInit } from '@angular/core';
import { ListOfSodaItems } from './json/listofsoda';
import { ListOfSoda } from './interface/list-of-sodat-items';
import { SODA_APP_CONSTANTS } from './constants/app-constants';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
public listOfSodaItems: ListOfSoda[] = [];
public selectedSodaItems: ListOfSoda;
public listOfItemsPurchased: ListOfSoda[] = [];
public insertedAmount: number;
public remainingAmount: number;
public returnedAmount: number;
public errorMessages: string;
public successMessages: string;

  constructor() { }

  ngOnInit() {
    // In real life we would like to make service call to database,
    // where we will get sodalist items and associated details like 'id', 'name', 'price' and 'quantitiy_available'.
    this.listOfSodaItems = ListOfSodaItems.items;
    this.setInitialValues();
  }

  setInitialValues(): void {
    this.insertedAmount = 0;
    this.returnedAmount = 0;
  }
  onSelect(item: ListOfSoda): void {
   this.selectedSodaItems = item;
   if (this.insertedAmount >= this.selectedSodaItems.price) {
    if (item.quantitiy_available > 0) {
      item.quantitiy_available = item.quantitiy_available - 1;
      this.dispendeSoda(this.selectedSodaItems);
      this.errorMessages = SODA_APP_CONSTANTS.EMPTY;
    } else {
      this.errorMessages = SODA_APP_CONSTANTS.ERROR_THERE_ARE + item.quantitiy_available + SODA_APP_CONSTANTS.SPACE +
      item.name + SODA_APP_CONSTANTS.ERROR_AVAILABLE_TO_BUY ;
      this.successMessages = SODA_APP_CONSTANTS.EMPTY;
    }
   } else {
     this.successMessages = SODA_APP_CONSTANTS.EMPTY;
     this.errorMessages = SODA_APP_CONSTANTS.ERROR_COINS_LESS_THAN_ENTERED;
   }
  }
  dispendeSoda(item: ListOfSoda): void {
    this.insertedAmount = this.insertedAmount - item.price;
    this.returnedAmount = this.insertedAmount;
    this.listOfItemsPurchased.push(item);
    this.successMessages = SODA_APP_CONSTANTS.SUCCESS_MESSAGE;
    if (this.returnedAmount !== 0) {
      this.successMessages = this.successMessages + SODA_APP_CONSTANTS.SUCCESS_MESSAGE_YOU_CAN +
      this.returnedAmount + SODA_APP_CONSTANTS.SUCCESS_MESSAGE_COINS;
    } else {
      this.successMessages = this.successMessages + SODA_APP_CONSTANTS.SUCCESS_MESSAGE_YOU_HAVE +
      this.returnedAmount + SODA_APP_CONSTANTS.SUCCESS_MESSAGE_YOU_HAVE_COINS;
    }
  }

  returnAmount(): void {
    if (this.returnedAmount !== 0) {
      this.successMessages = SODA_APP_CONSTANTS.SUCCESS_MESSAGE_WE_ARE_RETURNING + this.returnedAmount
      + SODA_APP_CONSTANTS.SUCCESS_MESSAGE_WE_ARE_RETURNING_COINS;
      this.returnedAmount = 0;
      this.insertedAmount = 0;
    } else {
      this.errorMessages = SODA_APP_CONSTANTS.ERROR_YOU_HAVE_NOTHING;
      this.successMessages = SODA_APP_CONSTANTS.EMPTY;
    }
    this.listOfItemsPurchased = [];
  }

  insertAmount(): void {
    if (this.insertedAmount > 0 ) {
      this.errorMessages =  SODA_APP_CONSTANTS.EMPTY;
      this.successMessages = SODA_APP_CONSTANTS.SUCCESS_SUCCESSFULLY_INSERTED
      + this.insertedAmount + SODA_APP_CONSTANTS.SUCCESS_SUCCESSFULLY_INSERTED_COINS;
      this.returnedAmount = this.insertedAmount;
    } else {
      this.successMessages =  SODA_APP_CONSTANTS.EMPTY;
      this.errorMessages = SODA_APP_CONSTANTS.ERROR_PLEASE_INSERT_COINS;
    }
    this.listOfItemsPurchased = [];
  }

}
