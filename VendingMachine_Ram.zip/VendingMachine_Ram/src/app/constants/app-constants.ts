export const SODA_APP_CONSTANTS = {
  ERROR_PLEASE_INSERT_COINS: 'Please insert coins.',
  ERROR_COINS_LESS_THAN_ENTERED: 'The amount you have enetered is less than the item amount. Please insert more coins.',
  ERROR_YOU_HAVE_NOTHING: 'You have nothing to return. Please insert coins.',
  ERROR_THERE_ARE: 'There are ',
  ERROR_AVAILABLE_TO_BUY: ' available to buy. Please choose different soda item.',
  SUCCESS_MESSAGE: 'Enjoy your soda drink. ',
  SUCCESS_MESSAGE_YOU_CAN: 'You can still avail some more drinks with the remaining $ ',
  SUCCESS_MESSAGE_COINS: ' coins.',
  SUCCESS_MESSAGE_YOU_HAVE: 'You have $ ',
  SUCCESS_MESSAGE_YOU_HAVE_COINS: ' coins to return. Please insert some more coins to get soda drink.',
  SUCCESS_MESSAGE_WE_ARE_RETURNING : 'We are returning $ ',
  SUCCESS_MESSAGE_WE_ARE_RETURNING_COINS: ' coins. Please take it before you leave from the vending machine. Thank you visit again.',
  SUCCESS_SUCCESSFULLY_INSERTED: 'Successfully  inserted $',
  SUCCESS_SUCCESSFULLY_INSERTED_COINS: 'coins. Select a soda item to despense.',
  EMPTY: '',
  SPACE: ' ',


};

