export const ListOfSodaItems = {
items: [
        {
            id: '1',
            name: 'Coca cola',
            price: 2,
            quantitiy_available: 5,
        },
        {
            id: '2',
            name: 'Diet Coke',
            price: 5,
            quantitiy_available: 2,
        },
        {
            id: '3',
            name: 'Dr. Prepper',
            price: 3,
            quantitiy_available: 7,
        },
        {
            id: '4',
            name: 'Sprite',
            price: 10,
            quantitiy_available: 9,
        },
        {
            id: '5',
            name: 'Fanta',
            price: 4,
            quantitiy_available: 6,
        },
        {
            id: '6',
            name: 'Ginger Ale',
            price: 1,
            quantitiy_available: 8,
        },
    ]
}
